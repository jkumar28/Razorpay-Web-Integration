<?php
require 'vendor/autoload.php'; // Make sure to include Composer's autoload file
use Razorpay\Api\Api;

// Razorpay Test API keys
$apiKey = 'rzp_test_lmNLU4YEh2ncs8';
$apiSecret = '13plcw3YMY0OiVNyhUMVDaXi';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $api = new Api($apiKey, $apiSecret);

    $amount = $_POST['amount'] * 100; // Amount in paise
    $orderData = [
        'receipt' => 'rcptid_11',
        'amount' => $amount,
        'currency' => 'INR',
        'payment_capture' => 1 // Auto capture
    ];

    $razorpayOrder = $api->order->create($orderData);
    $orderId = $razorpayOrder['id'];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Razorpay Payment Integration</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
</head>

<body>

    <form id="paymentForm" method="post">
        <input type="text" name="name" id="name" value="Jitendra Kumar" placeholder="Enter Name" required>
        <input type="email" name="email" id="email" placeholder="Enter Email" required>
        <input type="text" name="phone" id="phone" placeholder="Enter Mobile Number" required>
        <input type="text" id="amount" name="amount" value="205" placeholder="Amount" required>
        <button type="submit">Pay Now</button>
    </form>

    <?php if (isset($orderId)) { ?>
        <script>
            $(document).ready(function() {
                var options = {
                    "key": "<?php echo $apiKey; ?>", // Enter the Key ID generated from the Dashboard
                    "amount": "<?php echo $amount; ?>", // Amount in paise
                    "currency": "INR",
                    "name": "The Fun Spot",
                    "description": "Online Ticket Booking",
                    "image": "https://thefunspot.in/assets/image/funlogo.png",
                    "order_id": "<?php echo $orderId; ?>",
                    "handler": function(response) {
                        // Redirect to a thank you page with payment details
                        window.location.href = 'thankyou.php?payment_id=' + response.razorpay_payment_id + '&order_id=' + response.razorpay_order_id + '&signature=' + response.razorpay_signature;
                    },
                    "prefill": {
                        "name": "<?php echo $_POST['name']; ?>",
                        "email": "<?php echo $_POST['email']; ?>",
                        "contact": "<?php echo $_POST['phone']; ?>"
                    },
                    "theme": {
                        "color": "#F37254"
                    }
                };
                var rzp1 = new Razorpay(options);
                rzp1.open();
            });
        </script>
    <?php } ?>
</body>

</html>