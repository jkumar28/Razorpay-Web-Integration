<?php
// thankyou.php
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $paymentId = $_GET['payment_id'];
    $orderId = $_GET['order_id'];
    $signature = $_GET['signature'];

    // You can use these details to verify the payment and update the order status in your database

    echo "Payment Successful!<br>";
    echo "Payment ID: " . htmlspecialchars($paymentId) . "<br>";
    echo "Order ID: " . htmlspecialchars($orderId) . "<br>";
    echo "Signature: " . htmlspecialchars($signature);
}
?>
