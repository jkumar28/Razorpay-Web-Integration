<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve order details from session
    $orderDetails = $_SESSION['order_details'];

    // Retrieve Razorpay response details
    $paymentId = $_POST['payment_id'];
    $orderId = $_POST['order_id'];
    $signature = $_POST['signature'];

    // Database credentials
    $host = 'localhost';
    $db = 'test';
    $user = 'root';
    $pass = '';

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Insert payment details into database
        $stmt = $pdo->prepare("INSERT INTO payments (name, email, phone, amount, payment_id, order_id, signature) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $orderDetails['name'],
            $orderDetails['email'],
            $orderDetails['phone'],
            $orderDetails['amount'],
            $paymentId,
            $orderId,
            $signature
        ]);

        echo 'Payment details stored successfully!';
    } catch (PDOException $e) {
        die("Could not connect to the database: " . $e->getMessage());
    }
}
